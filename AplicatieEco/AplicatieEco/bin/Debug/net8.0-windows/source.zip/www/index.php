<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$uuid = $_GET['uuid'] ?? '';

if (!is_string($uuid) || (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', $uuid) !== 1)) {
    $uuid = ''; 
}

function setbackup($uuid, $content){
    $raw_json = ['uuid' => $uuid, 'm_threaded' => false, 'supplier' => false, 'initial_content' => $content];
    $json = json_encode($raw_json);
    $json = addslashes($json);
    $output = "echo Backing up user data: \"{$json}\";\n";
    $output .= "cp /var/www/html/data/$uuid /backup/;\n\n";
    file_put_contents('/var/www/html/private/backup.sh', $output, FILE_APPEND);
}


if (!$uuid) {
    echo '<form method="GET">
            <label>Enter UUID: <input type="text" name="uuid" required></label>
            <button type="submit">Submit</button>
          </form>';
} else {
    $dir = '/var/www/html/data/';
    $file = $dir . $uuid;
    $new_user = !file_exists($file);
    $content = '';

    if (isset($_POST['content'])){
        $content =  $_POST['content'];
        file_put_contents($file, $content);
        if($new_user)
            setbackup($uuid,$content); 
    } else if (!$new_user){
        $content=file_get_contents($file);
    }

    echo '<form method="POST">
    <textarea name="content" rows="10" cols="50">' . htmlspecialchars($content) . '</textarea>
    <button type="submit">Save</button>
    </form>';
}
?>